# Nales Data Storage init file
