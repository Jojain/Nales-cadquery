import setuptools

setuptools.setup()
# setuptools.setup(
#     install_requires=[
#         "pyqt5",
#         "qt-material",
#         "qtconsole",
#         # "ncadquery @ git+https://github.com/Jojain/cadquery.git@nales_cadquery#egg=ncadquery",
#         # "ncadquery @ git+ssh://git@github.com/Jojain/cadquery.git@nales_cadquery",
#     ],
#     dependency_links=[
#         "git+https://github.com/Jojain/cadquery.git@nales_cadquery#egg=ncadquery"
#     ],
# )
