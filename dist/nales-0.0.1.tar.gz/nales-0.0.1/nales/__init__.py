# from nales.main_window import main

# main()
